import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface User {
  firstName: string;
  lastName: string;
  email: string;
  isAdmin: boolean;
}

interface Entity {
  name: string;
  type: string;
  admin: User;
}

@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})
export class AdminComponent {
  user: User = {
    firstName: '',
    lastName: '',
    email: '',
    isAdmin: false
  };

  entity: Entity = {
    name: '',
    type: '',
    admin: { firstName: '', lastName: '', email: '', isAdmin: true }}}
